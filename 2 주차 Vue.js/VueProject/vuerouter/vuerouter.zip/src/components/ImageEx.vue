<template>
	<div>
		<h2>게시판 리스트</h2>
	</div>
</template>

<script>
export default {
	
}
</script>

<style scoped>

</style>